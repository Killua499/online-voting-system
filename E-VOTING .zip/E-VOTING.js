let voters = [];

// Add this flag to enable skipping auto-login during debugging
const isDebugging = localStorage.getItem("isDebugging") === "true";

// Preload sample users (voters with login access)
if (!localStorage.getItem("users")) {
  const placeholderPhoto = "https://via.placeholder.com/120";
  const sampleUsers = [
    { id: "V001", name: "Alice Santos", password: "alice123", photo: placeholderPhoto },
    { id: "V002", name: "Bryan Cruz", password: "bryan123", photo: placeholderPhoto },
    { id: "V003", name: "Chloe Dela Peña", password: "chloe123", photo: placeholderPhoto },
    { id: "V004", name: "Daniel Reyes", password: "daniel123", photo: placeholderPhoto },
    { id: "V005", name: "Ella Francisco", password: "ella123", photo: placeholderPhoto },
    { id: "V006", name: "Francis Lim", password: "francis123", photo: placeholderPhoto },
    { id: "V007", name: "Grace Tan", password: "grace123", photo: placeholderPhoto },
    { id: "V008", name: "Harold Uy", password: "harold123", photo: placeholderPhoto },
    { id: "V009", name: "Isabelle Gomez", password: "isabelle123", photo: placeholderPhoto },
    { id: "V010", name: "James Navarro", password: "james123", photo: placeholderPhoto }
  ];
  localStorage.setItem("users", JSON.stringify(sampleUsers));
}

// Auto-login if user session exists and not debugging
window.onload = function() {
  if (!isDebugging) {
    const userId = localStorage.getItem("user");
    if (userId) {
      document.getElementById("loginScreen").style.display = "none";
      document.getElementById("mainApp").style.display = "block";
      updateVoteTally();
      updateDashboardStats();
      renderVoterList();
      
      const user = JSON.parse(localStorage.getItem("users") || "[]").find(u => u.id === userId);
      if (user && user.photo) {
        document.getElementById("userPhoto").src = user.photo;
        document.getElementById("userPhoto").style.display = "block";
      }
    }
  }
};

function login(event) {
  event.preventDefault();
  
  const id = document.getElementById("idNumber").value.trim();
  const pass = document.getElementById("password").value.trim();
  const fullName = document.getElementById("fullName")?.value.trim().toLowerCase();
  
  let users = JSON.parse(localStorage.getItem("users")) || [];
  const user = users.find(u =>
    u.id === id && u.password === pass && u.name.trim().toLowerCase() === fullName
  );
  
  if (user) {
    localStorage.setItem("user", id);
    
    document.getElementById("loginScreen").style.display = "none";
    document.getElementById("signupScreen").style.display = "none";
    document.getElementById("mainApp").style.display = "block";
    
    document.getElementById("userPhoto").src = user.photo || "";
    document.getElementById("userPhoto").style.display = "block";
    
    updateVoteTally();
    updateDashboardStats();
    renderVoterList();
  } else {
    alert("Invalid login credentials.");
  }
}

function signup(event) {
  event.preventDefault();
  
  const id = document.getElementById("newID").value.trim();
  const name = document.getElementById("newName").value.trim();
  const password = document.getElementById("newPassword").value;
  const placeholderPhoto = "https://via.placeholder.com/120";
  
  if (!id || !name || !password) {
    alert("Please fill in all fields.");
    return;
  }
  
  const users = JSON.parse(localStorage.getItem("users") || "[]");
  
  if (users.some(user => user.id === id)) {
    alert("A user with this ID already exists.");
    return;
  }
  
  const newUser = { id, name, password, photo: placeholderPhoto };
  users.push(newUser);
  localStorage.setItem("users", JSON.stringify(users));
  
  alert("Signup successful!");
  toggleForm('login');
}

function toggleForm(form) {
  document.getElementById("loginScreen").style.display = form === "signup" ? "none" : "block";
  document.getElementById("signupScreen").style.display = form === "signup" ? "block" : "none";
}

function renderVoterList(users = null) {
  const voterList = document.getElementById("voterList");
  voterList.innerHTML = "";
  
  if (!users) users = JSON.parse(localStorage.getItem("users") || "[]");
  
  if (users.length === 0) {
    voterList.innerHTML = "<li>No registered voters found.</li>";
  } else {
    users.forEach(user => {
      const li = document.createElement("li");
      li.textContent = `${user.name} (ID: ${user.id})`;
      voterList.appendChild(li);
    });
  }
}

function updateDashboardStats() {
  const users = JSON.parse(localStorage.getItem("users") || "[]");
  const votes = JSON.parse(localStorage.getItem("votes") || "[]");
  
  document.getElementById("positionsCount").textContent = "3";
  document.getElementById("candidatesCount").textContent = "12";
  document.getElementById("votersCount").textContent = users.length;
  document.getElementById("votedCount").textContent = votes.length;
  
  const votedBar = document.getElementById("votedBar");
  const totalVotersBar = document.getElementById("totalVotersBar");
  
  const percent = users.length ? (votes.length / users.length) * 100 : 0;
  totalVotersBar.innerHTML = `<div style="width: 100%; background: gray;"></div>`;
  votedBar.innerHTML = `<div style="width: ${percent}%; background: #00ffcc;"></div>`;
}

function logout() {
  localStorage.removeItem("user");
  document.getElementById("mainApp").style.display = "none";
  document.getElementById("loginScreen").style.display = "block";
}

function addVoter(event) {
  event.preventDefault();
  
  const voterName = document.getElementById("voterName").value.trim();
  const voterID = document.getElementById("voterID").value.trim();
  const placeholderPhoto = "https://via.placeholder.com/120";
  
  if (!voterName || !voterID) {
    alert("Please provide both name and ID.");
    return;
  }
  
  const users = JSON.parse(localStorage.getItem("users") || "[]");
  if (users.some(u => u.id === voterID)) {
    alert("Voter ID already exists.");
    return;
  }
  
  users.push({ name: voterName, id: voterID, password: "default123", photo: placeholderPhoto });
  localStorage.setItem("users", JSON.stringify(users));
  renderVoterList();
}

function handleImage(event) {
  const preview = document.getElementById("preview");
  const file = event.target.files[0];
  
  if (file) {
    const reader = new FileReader();
    reader.onload = function(e) {
      preview.src = e.target.result;
    };
    reader.readAsDataURL(file);
  }
}

function updateVoteTally() {
  const votes = JSON.parse(localStorage.getItem("votes") || "[]");
  const tally = { mayor: {}, secretary: {}, treasurer: {} };
  
  votes.forEach(vote => {
    if (vote.mayor) tally.mayor[vote.mayor] = (tally.mayor[vote.mayor] || 0) + 1;
    if (vote.secretary) tally.secretary[vote.secretary] = (tally.secretary[vote.secretary] || 0) + 1;
    if (vote.treasurer) tally.treasurer[vote.treasurer] = (tally.treasurer[vote.treasurer] || 0) + 1;
  });
  
  const renderTally = (position, data) => {
    let html = `<h4>${position.charAt(0).toUpperCase() + position.slice(1)}</h4><ul>`;
    for (const candidate in data) {
      html += `<li>${candidate}: ${data[candidate]} votes</li>`;
    }
    html += `</ul>`;
    return html;
  };
  
  document.getElementById("mayorTally").innerHTML = renderTally("mayor", tally.mayor);
  document.getElementById("secretaryTally").innerHTML = renderTally("secretary", tally.secretary);
  document.getElementById("treasurerTally").innerHTML = renderTally("treasurer", tally.treasurer);
}

function submitVote(event) {
  event.preventDefault();
  const userId = localStorage.getItem("user");
  if (!userId) return alert("Please login to vote.");
  
  const voteData = {
    mayor: document.querySelector('input[name="mayor"]:checked')?.value,
    secretary: document.querySelector('input[name="secretary"]:checked')?.value,
    treasurer: document.querySelector('input[name="treasurer"]:checked')?.value,
    userId: userId
  };
  
  if (!voteData.mayor || !voteData.secretary || !voteData.treasurer) {
    return alert("Please vote for all positions.");
  }
  
  let votes = JSON.parse(localStorage.getItem("votes") || "[]");
  if (votes.some(v => v.userId === userId)) {
    return alert("You have already voted.");
  }
  
  votes.push(voteData);
  localStorage.setItem("votes", JSON.stringify(votes));
  alert("Vote submitted successfully.");
  updateVoteTally();
  updateDashboardStats();
}

function disappearAndShow(button, page) {
  showPage(page);
}

function searchVoter(event) {
  event.preventDefault();
  const input = document.getElementById("searchVoterName");
  const query = input.value.trim().toLowerCase();
  const users = JSON.parse(localStorage.getItem("users")) || [];
  
  const filtered = users.filter(u =>
    (u.name?.toLowerCase().includes(query) || false) ||
    (u.id?.toLowerCase().includes(query) || false)
  );
  
  renderVoterList(filtered);
}